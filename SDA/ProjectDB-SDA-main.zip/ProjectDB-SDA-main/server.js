const express=require ("express")
const app = express ()

const logger = require('morgan');
const bodyParser = require("body-parser");
const cors = require("cors");//front end aur server k darmiyan communication k lye hy


// set port, listen for requests
const PORT = process.env.PORT || 2000;
require('dotenv').config();

app.use(cors());

// parse requests of content-type - application/json
app.use(bodyParser.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// logger
app.use(logger('dev'));//jo bh api use ho rhi hoti hy to ye btata hy k hit hui ya nh.

const db = require("./app/models");

db.mongoose
  .connect(process.env.URL, { 
    useNewUrlParser: true, 
    useCreateIndex: true, 
    useUnifiedTopology: true, 
    useFindAndModify: false
  })
  .then(() => {
    console.log("Successfully connect to MongoDB.");
    // initial();
  })
  .catch(err => {
    console.error("Connection error", err);
    process.exit();
  });
require("./app/routes/stops.routes")(app)//controller require kr rhy
require("./app/routes/customer.routes")(app)//controller require kr rhy
require("./app/routes/fare.routes")(app)//controller require kr rhy
require("./app/routes/carpooler.routes")(app)//controller require kr rhy

app.listen(2000,()=>{console.log("serverlistening")})
