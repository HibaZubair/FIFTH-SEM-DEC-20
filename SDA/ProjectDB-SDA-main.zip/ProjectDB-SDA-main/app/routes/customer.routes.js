

const controller = require("../controller/customer.controller")
module.exports=function(app){
    app.post("/api/customer/create",controller.create)
    app.get("/api/customer/getall",controller.getall)
    app.put("/api/customer/update/:id",controller.update)
    app.delete("/api/customer/delete/:id",controller.delete)
}