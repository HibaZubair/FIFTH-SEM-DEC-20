

const controller = require("../controller/carpooler.controller")
module.exports=function(app){
    app.post("/api/carpooler/create",controller.create)
    app.get("/api/carpooler/getall",controller.getall)
    app.put("/api/carpooler/update/:id",controller.update)
    app.delete("/api/carpooler/delete/:id",controller.delete)
}