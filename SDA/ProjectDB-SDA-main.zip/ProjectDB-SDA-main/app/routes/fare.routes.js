

const controller = require("../controller/fare.controller")
module.exports=function(app){
    app.post("/api/fare/create",controller.create)
    app.get("/api/fare/getall",controller.getall)
    app.put("/api/fare/update/:id",controller.update)
    app.delete("/api/fare/delete/:id",controller.delete)
}