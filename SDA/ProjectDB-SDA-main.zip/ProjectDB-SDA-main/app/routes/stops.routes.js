

const controller = require("../controller/stops.controller")
module.exports=function(app){
    app.post("/api/stop/create",controller.create)
    app.get("/api/stop/getall",controller.getall)
    app.put("/api/stop/update/:id",controller.update)
    app.delete("/api/stop/delete/:id",controller.delete)
}