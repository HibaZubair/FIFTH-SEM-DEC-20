

const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const CarpoolerSchema = new Schema(
    {
        Carpooler_Name       :   { type : String, require: true },
        Phone_Number         :   { type : Number, require: true, unique: true},
        //Seats ka kch setup bh krna hy
        stop_id : {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Stops"
          },
    },
    {timestamps: true}//created time updated time khud utha lega.
)
module.exports = mongoose.model('Carpoolers',CarpoolerSchema)