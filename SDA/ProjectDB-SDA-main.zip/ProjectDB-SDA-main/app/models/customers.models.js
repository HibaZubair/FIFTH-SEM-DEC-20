

const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const CustomerSchema = new Schema(
    {
        Customer_Name       :   { type : String, require: true },
        stop_id : {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Stops"
          },
    },
    {timestamps: true}//created time updated time khud utha lega.
)
module.exports = mongoose.model('Customers',CustomerSchema)