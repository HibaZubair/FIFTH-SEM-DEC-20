

const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const FareSchema = new Schema(
    {
        Car_Name       :   { type : String, require: true },
        Car_Type       :   { type : String , require : true}
          
    },
    {timestamps: true}//created time updated time khud utha lega.
)
module.exports = mongoose.model('Fares',FareSchema)