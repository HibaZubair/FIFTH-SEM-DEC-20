const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

const db = {};

db.mongoose = mongoose;

db.Stops=require("./stops.models")

db.Customers=require("./customers.models")
db.Fares=require("./fare.models")
db.Carpoolers=require("./carpoolers.models")

module.exports = db;