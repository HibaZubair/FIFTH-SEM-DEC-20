

const mongoose = require('mongoose')
const Schema = mongoose.Schema;

const StopSchema = new Schema(
    {
        Stop_Name       :   { type : String, require: true, unique:true },
          
    },
    {timestamps: true}//created time updated time khud utha lega.
)
module.exports = mongoose.model('Stops',StopSchema)