const { request } = require("express")
const db = require("../models")

const Stops = db.Stops

exports.create = (req,res)=>{
    if (!req.body.stop_name){
        return res.status(400).send({message : "Bad Request"})

    }
    let stop = new Stops({Stop_Name : req.body.stop_name})
    stop.save((err,data)=>{
        if (err){ 
            return res.status(500).send({ message: err });
        }

        return res.status(201).send({message:"success"})
    })
}//request user krta hy,response server kry ga.

exports.getall = (req,res)=>{
    Stops.find({})
    .exec((err, data) => {
      if (err){ 
        return res.status(500).send({ message: err });
      }
      return res.status(200).send({message:"success",data:data})
    })
}

//req.param.id front end se ayegi
exports.update = (req,res)=>{
    Stops.updateOne({_id: req.params.id} , { $set : req.body},  {upsert: true }, (err, data)=>{
        if(err)
          return res.status(500).send({ message: err });
        return res.status(200).send({message:"success"})
      })
}


exports.delete = (req,res)=>{
    Stops.deleteOne({_id : req.params.id} , (err,data)=>{
        if(err)
          return res.status(500).send({ message: err });
    
        return res.status(200).send({message:"success"})
      })
}