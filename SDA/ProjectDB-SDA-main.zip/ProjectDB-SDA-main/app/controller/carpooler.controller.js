const { request } = require("express")
const db = require("../models")

const Carpoolers = db.Carpoolers

exports.create = (req,res)=>{
    if (!req.body.carpooler_name || !(req.body.phone_number) || !(req.body.Stop_id)){
        return res.status(400).send({message : "Bad Request"})

    }
    let carpooler = new Carpoolers({Carpooler_Name : req.body.carpooler_name,Phone_Number : req.body.phone_number, stop_id : req.body.Stop_id})
    carpooler.save((err,data)=>{
        if (err){ 
            return res.status(500).send({ message: err });
        }

        return res.status(201).send({message:"success"})
    })
}//request user krta hy,response server kry ga.

exports.getall = (req,res)=>{
    Carpoolers.find({}).populate("stops")
    .exec((err, data) => {
      if (err){ 
        return res.status(500).send({ message: err });
      }
      return res.status(201).send({message:"success",data:data})
    })
}

exports.update = (req,res)=>{
    Carpoolers.updateOne({_id: req.params.id} , { $set : req.body},  {upsert: true }, (err, data)=>{
        if(err)
          return res.status(500).send({ message: err });
        return res.status(200).send({message:"success"})
      })
}


exports.delete = (req,res)=>{
    Carpoolers.deleteOne({_id : req.params.id} , (err,data)=>{
        if(err)
          return res.status(500).send({ message: err });
    
        return res.status(200).send({message:"success"})
      })
}