const { request } = require("express")
const db = require("../models")

const Fares = db.Fares

exports.create = (req,res)=>{
    if (!req.body.car_name || !(req.body.car_type)){
        return res.status(400).send({message : "Bad Request"})
      
} 

    
    let fare = new Fares({Car_Name : req.body.car_name, Car_Type : req.body.car_type})
    fare.save((err,data)=>{
        if (err){ 
            return res.status(500).send({ message: err });
        }

        return res.status(201).send({message:"success"})
    })
}//request user krta hy,response server kry ga.

exports.getall = (req,res)=>{
    Fares.find({})
    .exec((err, data) => {
      if (err){ 
        return res.status(500).send({ message: err });
      }
      return res.status(201).send({message:"success",data:data})
    })
}

exports.update = (req,res)=>{
    Fares.updateOne({_id: req.params.id} , { $set : req.body},  {upsert: true }, (err, data)=>{
        if(err)
          return res.status(500).send({ message: err });
        return res.status(200).send({message:"success"})
      })
}


exports.delete = (req,res)=>{
    Fares.deleteOne({_id : req.params.id} , (err,data)=>{
        if(err)
          return res.status(500).send({ message: err });
    
        return res.status(200).send({message:"success"})
      })
}