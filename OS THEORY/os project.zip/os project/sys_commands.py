import os
import main
import subprocess
import speech_recognition as sr
import datetime
import webbrowser

def commands(command):
    if command == "list files":
        subprocess.run(["ls"])
        
    elif command == "create a text file":
        name=input("Enter File name:")
        main.sound("Enter file name:")
        if os.path.exists(name):
            print("File already exists")
            main.sound("File already exists")
        else:
            subprocess.run(["touch",name + ".txt"])
            print("File Created Successfully")
            main.sound("File Created Successfully")
            
    elif command == "delete a file" or command == "remove a file":
        main.sound("Enter file name: ")
        name = input("Enter file name: ")
        if os.path.exists(name):
            subprocess.run(["rm",name])
            main.sound("File deleted successfully")
            print("File deleted successfully")
        else:
            main.sound("File not found")
            print("File not found")
            
    elif command == "list users":
        subprocess.run(["ls","/home"])
        
    elif command == "list formatted files":
        subprocess.run(["ls","-l"])
    
    elif command == "list hidden files":
        subprocess.run(["ls","-a"])
        
    elif command == "create a folder" or command == "create a directory" or command == "make a folder" or command == "make a directory":
        main.sound("Enter folder name")
        name = input("Enter folder Name: ")
        if os.path.exists(name):
            main.sound("A folder with same name exists")
        else:
            subprocess.run(["mkdir",name])
            main.sound("Folder created successfully")
            
    elif command == "delete a folder" or command == "delete a directory" or command == "remove a folder" or command == "remove a directory":
        main.sound("Enter folder name")
        name = input("Enter folder Name: ")
        if os.path.exists(name):
            subprocess.run(["rmdir",name])
            print("Deleted File")
            main.sound("Folder Deleted Successfully")
        else:
            main.sound("Folder not found")
    # elif command == "go to home directory":
    #     os.system("cd /home")
    elif command == "what is my current directory" or command == "current directory":
        s = str(subprocess.check_output(['pwd']))
        print("Your current directory is: " + s)
        main.sound(s)
        
    elif command == "what is the date today":
        # date = str(subprocess.check_output(['date','+%A']))
        date = str(datetime.date.today())
        print(date)
        main.sound(date)
        
    elif command == "what is the time":
        times = str(subprocess.check_output(['date','+%T']))
        time = datetime.datetime.now()
        print(time.strftime("%H:%M:%S"))
        main.sound(times)
            
    elif command == "open nano":
        subprocess.run("nano")
    
    elif command == "open gedit":
        subprocess.run("gedit")
    
    elif command == "open sublime":
        subprocess.run("subl")

    elif command == "open nano file":
        main.sound("Enter File name:")
        name = input("Enter File name:")
        subprocess.run(["nano",name])
    
    elif command == "open gedit file":
        main.sound("Enter File name:")
        name = input("Enter File name:")
        subprocess.run(["gedit",name])

    elif command == "open sublime file":
        main.sound("Enter File name:")
        name = input("Enter File name:")
        subprocess.run(["subl",name])
        
    elif command == "show network status":
        net = str(subprocess.check_output(["ifconfig"]))
        print(net)
    
    elif command == "change volume":
        main.sound("Enter volume level: ")
        v = input("Enter Volume level:")
        subprocess.call(["amixer", "-D", "pulse", "sset", "Master", v+"%"])#function used to change the volume fo the system
        print("Volume level now = ",v)
    
    elif command == "increase volume":
        subprocess.call(["amixer", "-D", "pulse", "sset", "Master", "10%+"])
     
    elif command == "decrease volume":
        subprocess.call(["amixer", "-D", "pulse", "sset", "Master", "10%-"])
    
    elif command == "mute":
        subprocess.call(["amixer", "-D", "pulse", "sset", "Master", "mute"])
    
    elif command == "unmute":
        subprocess.call(["amixer", "-D", "pulse", "sset", "Master", "unmute"])
    
    elif command == "open calculator":
         os.system("gnome-calculator")
        
# =================web commmands==================== #

    elif command == "open website":
        main.sound("Enter website name: ")
        web = input("Enter website name:")
        web = web.lower()
        path = "/usr/bin/firefox" #to access google chrome
        webbrowser.get(path).open_new_tab("www." + web + ".com")
    
    elif command == "open google":
        path = "/usr/bin/firefox"
        webbrowser.get(path).open_new_tab("www.google.com")
    
    elif command == "google search":
        main.sound("What do you want to search?")
        search = input("What do you want to search?")
        path = "/usr/bin/firefox"
        url = "https://www.google.com.tr/search?q={}".format(search)
        webbrowser.get(path).open_new_tab(url)
    
    elif command == "open youtube":
        path = "/usr/bin/firefox"
        webbrowser.get(path).open_new_tab("www.youtube.com")
    
    elif command == "open gmail":
        path = "/usr/bin/firefox"
        webbrowser.get(path).open_new_tab("www.gmail.com")
    