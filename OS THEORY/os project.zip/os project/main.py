from gtts import gTTS
import speech_recognition as sr
import os
import datetime
import sys_commands

def sound(voice):
    inp = gTTS(text=voice, lang='en')
    inp.save("tts.mp3")
    os.system("mpg321 -q tts.mp3")

def detectAudio(micro, recog):
    with micro as source:
        recog.adjust_for_ambient_noise(source,duration=1)
        audio = recog.listen(source)
    
    r = None
    
    try:
        r = recog.recognize_google(audio)
        return r
    except sr.RequestError:
        print("Audio is Unrecognizable")
    except sr.UnknownValueError:
        print("Unable to understand audio")
    return 'error'

if __name__ == "__main__":
    recog = sr.Recognizer()
    micro = sr.Microphone()

    sound("Welcome to the Speech Recognizing Operating System")
    sound("What can I do for you?")
    
    while True:
        response = detectAudio(micro,recog)
        
        if response == 'error':
            print("Error")
            continue
        elif response == "exit":
            print("Good Bye")
            sound("Good Bye")
            break
        else:
            command = str(format(response)).lower()
            print("You said: " + command)
            sound("You Said")
            sound(command)
            sys_commands.commands(command.lower())
            
            
        

        
    